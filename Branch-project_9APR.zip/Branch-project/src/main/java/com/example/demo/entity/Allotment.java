package com.example.demo.entity;



import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;

@Entity
@Table(name = "ALLOTMENT")
public class Allotment {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long allotmentId;
	@ManyToOne
	private Room room;
	@OneToOne
	private Student student;
	private Date allocationDate;
	private String status;
	transient SimpleDateFormat sdf;
	
	public Allotment() {
		sdf= new SimpleDateFormat("yyyy-MM-dd");
	}

	public Allotment(Long allotmentId, Room room, Student student, Date allocationDate, String status) {
		this();
		this.allotmentId = allotmentId;
		this.room = room;
		this.student = student;
		this.allocationDate = allocationDate;
		this.status=status;
	}
	
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Long getAllotmentId() {
		return allotmentId;
	}

	public void setAllotmentId(Long allotmentId) {
		this.allotmentId = allotmentId;
	}

	public Room getRoom() {
		return room;
	}

	public void setRoom(Room room) {
		this.room = room;
	}

	public Student getStudent() {
		return student;
	}

	public void setStudent(Student student) {
		this.student = student;
	}

	public String getAllocationDate1() {
		return sdf.format(allocationDate);
	}
	

	public Date getAllocationDate() {
		return allocationDate;
	}

	public void setAllocationDate(Date allocationDate) {
		this.allocationDate = allocationDate;
	}

	@Override
	public String toString() {
		return "Allotment [allotmentId=" + allotmentId + ", room=" + room + ", student=" + student + ", allocationDate="
				+ allocationDate + ", status=" + status + "]";
	}

	

	
	

}
