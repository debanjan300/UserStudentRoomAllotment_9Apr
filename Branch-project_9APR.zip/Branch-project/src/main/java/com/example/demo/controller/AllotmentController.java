package com.example.demo.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Allotment;
import com.example.demo.entity.Room;
import com.example.demo.service.AllotmentService;



@RestController
@RequestMapping("/allotment")
@CrossOrigin(origins= {"http://localhost:4200","*"})
public class AllotmentController {
	@Autowired
	private AllotmentService as;
	
	@GetMapping("/")
	public List<Allotment> getAllAllotment()
	{
		List<Allotment> allotmentList = as.read();
		return allotmentList;
	}
	
	@GetMapping("/{allotmentId}")
	public Allotment findByAllotmentId(@PathVariable("allotmentId") Long allotmentId) {
		return as.read(allotmentId);
	}
	
	@PostMapping("/")
	public Allotment addAllotment(@RequestBody Allotment allotment)
	{
		return as.create(allotment);
	}
	
	@PutMapping("/")
	public Allotment modifyAllotment(@RequestBody Allotment allotment)
	{
		return as.update(allotment);
	}
	
	@DeleteMapping("/{allotmentId}")
	public void deleteAllotment(@PathVariable("allotmentId") Long allotmentId)
	{
		as.delete(allotmentId);
	}
	@PostMapping("/statusUpdate/{allotmentId}")
	public void statusUpdate(@PathVariable("allotmentId") Long allotmentId)
	{
		 as.statusUpdate(allotmentId);
	}
	@PostMapping("/statusUpdate2/{allotmentId}")
	public void statusUpdate2(@PathVariable("allotmentId") Long allotmentId)
	{
		 as.statusUpdate2(allotmentId);
	}
//	@PostMapping("/decreaseOccupancy/{roomId}")
//	public void decreaseOccupancy(@PathVariable("roomId") Long roomId)
//	{
//		as.decreaseOccupancy(roomId);
//	}
	
	@PutMapping("/updateStatus/{allotmentId}/{status}")
	public Allotment updateStatus(@PathVariable("allotmentId") Long allotmentId, @PathVariable("status") String status)
	{
		//use the allotmentId, find the allotmentObject
		Allotment allotment = as.read(allotmentId);
		Room room=allotment.getRoom();
		int occupancy=room.getRoomOccupancy();
		if(status.equals("Approved"))
		{
			if(occupancy>1)
			{
				room.setRoomOccupancy(occupancy-1);
			}
			else if(occupancy==1)
			{
				room.setRoomOccupancy(0);
				room.setBookingStatus("Booked");
			}
		}else if(status.equals("Rejected"))
		{
			if(room.getBookingStatus().equals("Booked"))
				room.setBookingStatus("Available");
			room.setRoomOccupancy(occupancy+1);
		}
		return as.update(allotment);
	}

}
