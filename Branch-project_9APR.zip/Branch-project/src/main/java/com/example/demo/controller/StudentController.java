package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.Student;
import com.example.demo.entity.User;
import com.example.demo.service.StudentService;


@RestController
@RequestMapping("/student")
@CrossOrigin(origins = {"http://localhost:4200", "*"})
public class StudentController {
	@Autowired
	StudentService ss;
	@GetMapping("/")
    public List<Student> getAllStudents()
    {        
        List<Student> students = ss.read();
        return students;
    }
	@PostMapping("/")
    public Student addStudent(@RequestBody Student student)
    {
		System.out.println("Before:"+student);
		//obtain the user from user service and fill the user object of student.		student.setUser(user);
//		User user= ss.findUserByStudentId(student.getStudentId());
//		student.setUser(user);
//		System.out.println("After:"+student);
        return ss.create(student);
    }
    
    @PutMapping("/")
    public Student modifyStudent(@RequestBody Student student)
    {
        return ss.update(student);
    }
    
    @DeleteMapping("/{studentId}")
    public void deleteStudent(@PathVariable("studentId") Long studentId)
    {
        ss.delete(studentId);
    }
    
    @GetMapping("/{studentId}")            
    public Student findStudentById(@PathVariable("studentId") Long studentId)
    {
        return ss.read(studentId);
    }
    @GetMapping("/findByUserName/{userName}")            
    public Student findStudentByUserName(@PathVariable("userName") String userName)
    {
        return ss.read(userName);
    }
}
