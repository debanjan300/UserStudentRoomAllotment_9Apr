import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { Router } from '@angular/router';
import { AllotmentService } from '../allotment.service';
import { RoomService } from '../room.service';

@Component({
  selector: 'app-allotment',
  templateUrl: './allotment.component.html',
  styleUrls: ['./allotment.component.css']
})
export class AllotmentComponent implements OnInit {
  allotments:any;
  loggedRole:string|null="";
  
  constructor(private as:AllotmentService,private router:Router, private rs:RoomService) { }

  ngOnInit(): void {
    var loggedUserName=localStorage.getItem("loggedUserName");
    this.loggedRole=localStorage.getItem("loggedRole");
    
    if(loggedUserName==null)
    {
      alert("You have not logged in. Click OK to Login")
    this.router.navigateByUrl('/(col3:Login)');
    }
    else{
      if(this.loggedRole=="User"){
        alert("You are an "+this.loggedRole+". Click OK to continue.");
        this.router.navigateByUrl('/(col3:home)');
      }
      else{
        
    this.getAllAllotment();
        }
    }
  }
  getAllAllotment(){
    this.as.getAllAllotment().subscribe((data)=>{
      console.log(data);
      this.allotments=data;
    });
  }

  

  updateStatus(allotmentId:number, status:string)
  {
    console.log("Allotment component, fnApprove method: "+allotmentId);
    this.as.updateStatus(allotmentId,status).subscribe((data)=>{
      console.log("Response from rest api after updating the status (approved): ");
      console.log(data);
    });
  }
}
