import { Room } from "./room";
import { Student } from "./student";

export class Allotment {
    allotmentId:number=0;
    room:Room=new Room();
    student:Student=new Student();
    allocationDate:Date=new Date();
    status:string="";



    // private Long allotmentId;
	// @ManyToOne
	// private Room room;
	// @OneToOne
	// private Student student;
	// private Date allocationDate;
}
